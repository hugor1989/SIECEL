
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Administrar usuarios</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inicio</a></li>
              <li class="breadcrumb-item active">Administrar usuarios</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
  <section class="content">
    <div class="container-fluid">
            <div class="row">
               <div class="col-12 col-lg-8 ml-auto mr-auto mb-4">
                  <div class="multisteps-form__progress">
                     <button class="multisteps-form__progress-btn js-active" type="button" title="User Info">Informacion Usuario</button>
                     <button class="multisteps-form__progress-btn" type="button" title="Address">Informacion Empresa</button>
                     <!--<button class="multisteps-form__progress-btn" type="button" title="Order Info">Cuotas Usuario</button>-->
                     <button class="multisteps-form__progress-btn" type="button" title="Message">Cuotas Usuario</button>
                  </div>
               </div>
            </div>
    <div class="row">
                            <div class="col-12 col-lg-8 m-auto">
                                <form role="form" method="post" enctype="multipart/form-data" class="multisteps-form__form">
                                    <div class="multisteps-form__panel shadow p-4 rounded bg-white js-active" data-animation="scaleIn">
                                        <h3 class="multisteps-form__title">Info Inicio Sesion</h3>
                                        <div class="multisteps-form__content">
                                            <!-- ENTRADA PARA EL NOMBRE -->
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" name="nuevoNombre" placeholder="Nombre">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <span class="fas fa-user"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- ENTRADA PARA EL Email -->
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" name="nuevoEmail" placeholder="Email">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <span class="fa fa-envelope"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- ENTRADA PARA EL USUARIO -->
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" name="nuevoUsuario" placeholder="Usuario" id="nuevoUsuario">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <span class="fa fa-key"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- ENTRADA PARA LA CONTRASE�A -->
                                            <div class="input-group mb-3">
                                                <input type="password" class="form-control" name="nuevoPassword" placeholder="Password">
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <span class="fa fa-lock"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="button-row d-flex mt-4">
                                                <button class="btn btn-primary ml-auto js-btn-next" type="button" title="Next">Next</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="multisteps-form__panel shadow p-4 rounded bg-white" data-animation="scaleIn">
                                        <h3 class="multisteps-form__title">Info Empresa</h3>
                                        <div class="multisteps-form__content">
                                            <!-- Seleccionar Tipo de Perons-->
                                            <!-- ENTRADA PARA EL PERFIL -->
                                            <div class="input-group mb-3">
                                                <select class="form-control input-lg" name="nuevoPerfil">
                                                    <option value="">Selecionar Tipo de Persona</option>
                                                    <option value="Fisica">Fisica</option>
                                                    <option value="Moral">Moral</option>
                                                </select>
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <span class="fas fa-user"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- fin tipo de persona -->
                                            <div class="col">
                                                <input class="multisteps-form__input form-control" type="text" name="nuevoApoderado" id="nuevoApoderado" placeholder="Apoderado" disabled />
                                            </div>
                                            <!--Fin Apoderado-->
                                            <div class="form-row mt-4">
                                                <div class="col-12 col-sm-6">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoEmpresa" placeholder="Empresa" />
                                                </div>
                                                <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoRFC" placeholder="RFC" />
                                                </div>
                                            </div>
                                            <!-- Fin Empresa-->
                                            <div class="form-row mt-4">
                                                <div class="col-12 col-sm-6">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoCalle" placeholder="Calle" />
                                                </div>
                                                <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoNumeroInterior" placeholder="Numero Interior" />
                                                </div>
                                                <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoNumeroExterior" placeholder="NumeroExterior" />
                                                </div>
                                            </div>
                                            <!-- Fin calle-->
                                            <div class="form-row mt-4">
                                                <div class="col-12 col-sm-6">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoColonia" placeholder="Colonia" />
                                                </div>
                                                <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoMunicipio" placeholder="Municipio" />
                                                </div>
                                                <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoCP" placeholder="Codigo Postal" />
                                                </div>
                                            </div>
                                            <!-- Fin Colonia-->
                                            <div class="row">
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoEstado" placeholder="Estado" />
                                                </div>
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoPais" placeholder="Pais" />
                                                </div>
                                            </div>
                                            <!-- fin Pais-->
                                            <div class="row">
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoGiro" placeholder="Giro" />
                                                </div>
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoEmailAdicional" placeholder="Email Adicional" />
                                                </div>
                                            </div>
                                            <!-- fin Giro-->
                                            <div class="row">
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoTelefono" placeholder="Telefono" />
                                                </div>
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoCelular" placeholder="Celular" />
                                                </div>
                                            </div>
                                            <!-- fin Telefono-->
                                            <div class="row">
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoContacto" placeholder="Contacto" />
                                                </div>
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoNextel" placeholder="Nextel" />
                                                </div>
                                            </div>
                                            <!-- fin Nextel-->
                                            <div class="row">
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoCuentaBancaria" placeholder="Cuenta Bancaria" />
                                                </div>
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoCuentaBancariaAdicional" placeholder="Cuenta Bancaria Adicional" />
                                                </div>
                                            </div>
                                            <!-- fin Cuenta-->
                                            <div class="button-row d-flex mt-4">
                                                <button class="btn btn-primary js-btn-prev" type="button" title="Prev">Prev</button>
                                                <button class="btn btn-primary ml-auto js-btn-next" type="button" title="Next">Next</button>
                                            </div>
                                        </div>
                                        </div>
                                    <div class="multisteps-form__panel shadow p-4 rounded bg-white" data-animation="scaleIn">
                                        <h3 class="multisteps-form__title">Cuotas y Comisiones</h3>
                                        <div class="multisteps-form__content">
                                            <!-- Grupo de imput -->
                                            <div class="row">
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoComision" placeholder="Comision %" />
                                                </div>
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoAbreviatura" placeholder="Abreviatura" />
                                                </div>
                                            </div>
                                            <!-- fin de grupo input-->
                                            <!-- Grupo de imput -->
                                            <div class="row">
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoCuotaBasica" placeholder="Cuota basica antig. de vehículo y bienes usados" />
                                                </div>
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoCuota_Rot" placeholder="Cuota ROT y Robo" />
                                                </div>
                                            </div>
                                            <!-- fin de grupo input-->
                                            <!-- Grupo de imput -->
                                            <div class="row">
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoCuota_TR" placeholder="Cuota TR" />
                                                </div>
                                                <div class="col-12 col-md-6 mt-4">
                                                    <input class="multisteps-form__input form-control" type="text" name="nuevoCuota_Contenedor" placeholder="Cuota Contenedor" />
                                                </div>
                                            </div>
                                            <!-- fin de grupo input-->
                                            <!-- ENTRADA PARA EL PERFIL -->
                                             <div class="row">
                                            <div class="input-group mb-3">
                                                <select class="form-control input-lg" name="nuevoPerfil">
                                                    <option value="">Selecionar Perfil</option>

                                                    <?php
                                                    $perfil = ControladorUsuarios::mdlMostrarPerfiles($item, $valor);

                                                    foreach ($perfil as $key => $value){

                                                    ?>
                                                    <option value="<?php echo $value["Id"] ?>"><?php echo $value["Descripcion"] ?></option>

                                                    <?php
                                                    }
                                                    ?>

                                                </select>
                                                <div class="input-group-append">
                                                    <div class="input-group-text">
                                                        <span class="fas fa-user"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            </div>
                                            <!-- -->
                                            
                                            <div class="button-row d-flex mt-4">
                                                <button class="btn btn-primary js-btn-prev" type="button" title="Prev">Prev</button>
                                                <!--button class="btn btn-success ml-auto" type="button" title="Send">Send</button>-->
                                                <button type="submit" class="btn btn-success ml-auto">Guardar usuario</button>
                                            </div>
                                        </div>
                                    </div>
                                     <?php

                                      $crearUsuario = new ControladorUsuarios();
                                       $crearUsuario -> ctrCrearUsuario();
                                    ?>
                                </form>
                            </div>
                        </div>
            
    </div>
      <!-- /.container-fluid -->
  </section>

</div>


